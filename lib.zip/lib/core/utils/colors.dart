import 'package:flutter/material.dart';

const mobileBackgroundColor=Color.fromRGBO(24, 24, 24, 1);
const webBackgroundColor=Color.fromRGBO(18, 18, 18, 1);
const mobileSearchColor=Color.fromRGBO(0, 149, 246, 1);
const blueColor= Color.fromRGBO(0, 149, 246, 1);
const primaryColor=Colors.white;
const secondaryColor=Colors.grey;
const appbarColor=Color.fromRGBO(255, 155, 61, 1);